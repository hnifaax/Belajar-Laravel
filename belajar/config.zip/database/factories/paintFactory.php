<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\paint>
 */

{
    /**
     * Define the model's default state.
     *
     *
     */
    // public function definition()
    // {   
    //     $faker = Faker\Factory::create();
    //     return [
    //         //
    //         'judul' => $faker->name(), 
    //         'tahun' => mt_rand(0001, 9999),
    //         'artist' => $faker->name(),
    //         'class_id' => Arr::random([1, 2, 3]), 
    //     ];
    }

