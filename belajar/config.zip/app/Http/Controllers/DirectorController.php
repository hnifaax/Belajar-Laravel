<?php

namespace App\Http\Controllers;

use App\Models\Director;
use App\Http\Requests\StoreartistRequest;
use App\Http\Requests\UpdateartistRequest;

class DirectorController extends Controller
{
    
}
